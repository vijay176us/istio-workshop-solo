rm -fr ./istio-workshop-ca
rm -fr istioinaction.io.*